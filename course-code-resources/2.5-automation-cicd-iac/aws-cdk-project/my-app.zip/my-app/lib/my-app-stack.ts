import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam'
import path = require('path');


export class MyAppStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create an S3 Bucket
    const bucket = new s3.Bucket(this, 'MyBucket', {
      versioned: true
    } )

  // Create a Lambda function
  const lambdaFn = new lambda.Function(this,'ListBucketsFunction', {
    runtime: lambda.Runtime.PYTHON_3_10,
    handler: 'lambda-handler.handler',
    code: lambda.Code.fromAsset(path.join(__dirname, '../lambdas'))
  })

  // Create a Policy Statement
  const listBucketPolicy = new iam.PolicyStatement({
    effect:iam.Effect.ALLOW,
    actions:['s3:*'],
    resources:['*']
  });

  lambdaFn.role?.attachInlinePolicy(
    new iam.Policy(this, 'list-resources', {
      statements:[listBucketPolicy]
    })
  )

  

  }
}
